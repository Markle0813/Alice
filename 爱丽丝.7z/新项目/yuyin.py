import tkinter as tk
import speech_recognition as sr
import pygame
import threading

# 初始化pygame音频播放
pygame.mixer.init()

# 定义播放音频的函数
def play_audio(audio_name):
    # 加载音频
    pygame.mixer.music.load(audio_name)
    # 播放音频
    pygame.mixer.music.play()

# 定义语音识别的函数
def recognize_speech():
    recognizer = sr.Recognizer()
    mic = sr.Microphone()

    with mic as source:
        print("请说话")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)

    try:
        text = recognizer.recognize_google(audio, language='zh-CN')  # 识别中文
        print("识别内容:", text)
        handle_command(text)
    except sr.UnknownValueError:
        print("无法识别语音")
    except sr.RequestError:
        print("服务出错")

# 处理语音指令
def handle_command(command):
    if "你好爱丽丝" in command:
        play_audio('audio/hello_alice.mp3')
    #     注意: 音频文件要放在和yuyin.py文件相同的文件夹中且格式一致
    elif "关灯" in command:
        play_audio('audio/light1.mp3')
    elif "我想听故事" in command:
        play_audio('audio/story.mp3')
    elif "开灯" in command:
        play_audio('audio/light2.mp3')
    elif "停下来" in command:
        pygame.mixer.music.stop()
        print("音频停止播放")
    else:
        print("没有匹配的命令")

# 启动语音识别的线程
def start_voice_recognition():
    while True:
        recognize_speech()

# 创建GUI界面
def create_gui():
    root = tk.Tk()
    root.title("爱丽丝")
    root.geometry("300x150")

    label = tk.Label(root, text="与爱丽丝说话", font=("Arial", 14))
    label.pack(pady=30)

    # 启动语音识别线程
    threading.Thread(target=start_voice_recognition, daemon=True).start()

    # 按钮用于关闭程序
    quit_button = tk.Button(root, text="退出", command=root.quit)
    quit_button.pack()

    root.mainloop()

if __name__ == "__main__":
    create_gui()















